"""
Epsilon-Gate v0.2  —  분자 자동 생성기 추가
=============================================
v0.1: SMILES 를 사람이 넣어줘야 했음.
v0.2: 스캐폴드 + 작용기 조합으로 분자를 '대량 생성' → 게이트 자동 통과.

설계 철학 (Cheon Woon-ki):
  - 코어(스캐폴드)는 고정 = 합성 가능성/신뢰성 확보 (AP2601 의 아다만탄-OH)
  - 작용기만 조합 = 화학 공간을 체계적으로 탐색
  - 생성된 전부를 게이트에 흘려보내 성공+실패+사유를 데이터로 남김
"""

from rdkit import Chem
from rdkit.Chem import QED, Descriptors, Crippen, Lipinski
import pandas as pd
import itertools

# ----------------------------------------------------------------------
# 게이트 (v0.1 과 동일 — CNS 기준)
# ----------------------------------------------------------------------
CNS_GATE = {
    "name": "CNS / BBB-permeant lead hypothesis",
    "MW": (None, 450), "LogP": (2.0, 4.0), "TPSA": (None, 90),
    "HBD": (None, 3), "HBA": (None, 7), "QED": (0.5, None),
    "RotB": (None, 8), "Lipinski_violations": (None, 0),
}


def evaluate(smiles, gate):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return {"smiles": smiles, "status": "INVALID",
                "reasons": ["SMILES 파싱 실패"], "metrics": {}}
    mw = Descriptors.MolWt(mol); logp = Crippen.MolLogP(mol)
    tpsa = Descriptors.TPSA(mol); hbd = Lipinski.NumHDonors(mol)
    hba = Lipinski.NumHAcceptors(mol); qed = QED.qed(mol)
    rotb = Descriptors.NumRotatableBonds(mol)
    lip_v = sum([mw > 500, logp > 5, hbd > 5, hba > 10])
    metrics = {"MW": round(mw,2), "LogP": round(logp,3), "TPSA": round(tpsa,2),
               "HBD": hbd, "HBA": hba, "QED": round(qed,3),
               "RotB": rotb, "Lipinski_violations": lip_v}
    checks = {"MW": mw, "LogP": logp, "TPSA": tpsa, "HBD": hbd,
              "HBA": hba, "QED": qed, "RotB": rotb, "Lipinski_violations": lip_v}
    reasons = []
    for key, bounds in gate.items():
        if key == "name": continue
        lo, hi = bounds; val = checks[key]
        if lo is not None and val < lo: reasons.append(f"{key}={round(val,2)}<{lo}")
        if hi is not None and val > hi: reasons.append(f"{key}={round(val,2)}>{hi}")
    return {"smiles": smiles, "status": "PASS" if not reasons else "FAIL",
            "reasons": reasons, "metrics": metrics}


# ----------------------------------------------------------------------
# 분자 자동 생성기
# ----------------------------------------------------------------------
# 코어: 아다만탄-OH (AP2601 의 검증된 스캐폴드). [*] = 치환점
SCAFFOLD = "OC1(C2)CC3CC(C1)CC(C2)([*])C3"

# 작용기 라이브러리 — 링커 × 방향족 꼬리 조합
LINKERS = {
    "amide_ethyl":   "C(=O)NCC{TAIL}",      # AP2601 원본 계열
    "amide_propyl":  "C(=O)NCCC{TAIL}",
    "amide_direct":  "C(=O)N{TAIL}",
    "ether_ethyl":   "OCC{TAIL}",
    "amine_methyl":  "CN{TAIL}",
}

TAILS = {
    "methoxyphenyl": "C4=CC=C(OC)C=C4",     # AP2601 원본 꼬리
    "phenyl":        "C4=CC=CC=C4",
    "fluorophenyl":  "C4=CC=C(F)C=C4",
    "pyridyl":       "C4=CC=NC=C4",
    "hydroxyphenyl": "C4=CC=C(O)C=C4",
    "dimethoxy":     "C4=CC=C(OC)C(OC)=C4",
    "chlorophenyl":  "C4=CC=C(Cl)C=C4",
}


def generate_library():
    """스캐폴드 × 링커 × 꼬리 = 조합형 분자 라이브러리 생성."""
    molecules = []
    for (lname, ltmpl), (tname, tsmiles) in itertools.product(LINKERS.items(), TAILS.items()):
        rgroup = ltmpl.replace("{TAIL}", tsmiles)
        smiles = SCAFFOLD.replace("[*]", rgroup)
        # 정규화(canonical) — 유효성도 같이 확인
        mol = Chem.MolFromSmiles(smiles)
        canon = Chem.MolToSmiles(mol) if mol else smiles
        molecules.append({
            "id": f"{lname}__{tname}",
            "smiles": canon,
            "valid": mol is not None,
        })
    return molecules


def run(gate=CNS_GATE):
    lib = generate_library()
    rows = []
    for m in lib:
        r = evaluate(m["smiles"], gate)
        row = {"ID": m["id"], "SMILES": m["smiles"], "STATUS": r["status"],
               "REASONS": " ; ".join(r["reasons"]) if r["reasons"] else "—"}
        row.update(r["metrics"])
        rows.append(row)
    return pd.DataFrame(rows)


if __name__ == "__main__":
    df = run()
    pd.set_option("display.width", 220)
    pd.set_option("display.max_colwidth", 40)

    n = len(df)
    n_pass = (df.STATUS == "PASS").sum()
    n_fail = (df.STATUS == "FAIL").sum()
    n_inv = (df.STATUS == "INVALID").sum()

    print(f"\n게이트: {CNS_GATE['name']}")
    print(f"자동 생성된 분자: {n}개  (링커 {len(LINKERS)} × 꼬리 {len(TAILS)})")
    print("=" * 130)

    # 통과한 설계 가설
    passed = df[df.STATUS == "PASS"].sort_values("QED", ascending=False)
    print(f"\n[ 통과한 설계 가설: {n_pass}개 ]  ← 검증할 가치가 있는 출발선")
    print(passed[["ID", "MW", "LogP", "TPSA", "QED"]].to_string(index=False))

    print(f"\n[ 탈락: {n_fail}개 / 무효: {n_inv}개 ]  ← 실패 사유가 붙은 학습 자산")
    failed = df[df.STATUS == "FAIL"]
    print(failed[["ID", "LogP", "TPSA", "QED", "REASONS"]].head(12).to_string(index=False))

    print("\n" + "=" * 130)
    print(f"통과율: {n_pass}/{n} = {n_pass/n*100:.0f}%")
    print(f"실패 데이터(학습 자산): {n_fail+n_inv}/{n} = {(n_fail+n_inv)/n*100:.0f}%")

    # AP2601 이 이 라이브러리 안에 재현되는지 확인
    ap2601 = Chem.MolToSmiles(Chem.MolFromSmiles("OC1(C2)CC3CC(C1)CC(C2)(C(=O)NCCC4=CC=C(OC)C=C4)C3"))
    match = df[df.SMILES == ap2601]
    print(f"\nAP2601 재현 확인: {'있음 ('+match.iloc[0]['ID']+', '+match.iloc[0]['STATUS']+')' if len(match) else '없음'}")

    df.to_csv("/home/claude/v2_generated_library.csv", index=False)
    print("전체 라이브러리 저장 → v2_generated_library.csv")
