"""
Epsilon-Gate v0.1  —  Lab-in-the-Loop 최소 버전
================================================
설계자: Cheon Woon-ki 의 Epsilon-Gate 프로토콜을 코드로 구현

핵심 철학:
  - 성공만 남기지 않는다. 실패에 '왜(reason)'를 붙여서 보존한다.
  - 1차 스크리닝을 통과한 '설계 가설'을 대량으로, 검증툴 로그와 함께 출력한다.
  - 이것은 '신약 후보물질'이 아니라 '검증할 가치가 있는 출발선'이다.

천장(정직한 한계):
  - RDKit 1차 물성 + 약물성 지표까지만 자동 검증한다.
  - 도킹(ΔG), 100ns MD, 합성가능성, in-vitro 는 이 버전에 없다 (리소스 영역).
"""

from rdkit import Chem
from rdkit.Chem import QED, Descriptors, Crippen, Lipinski, RDConfig
import pandas as pd
import json
from datetime import datetime

# ----------------------------------------------------------------------
# 1. 게이트 기준 정의 (질병/타겟별로 바뀔 수 있는 '필터 설정')
#    아래는 CNS(중추신경계) 약물 기준 — AP2601 이 겨냥했던 그 조건.
# ----------------------------------------------------------------------
CNS_GATE = {
    "name": "CNS / BBB-permeant lead hypothesis",
    "MW":        (None, 450),      # CNS 는 보통 더 작아야 함
    "LogP":      (2.0, 4.0),       # BBB 통과 + 축적 위험 회피의 황금 구간
    "TPSA":      (None, 90),       # 90 Å² 초과시 BBB 통과 급감
    "HBD":       (None, 3),
    "HBA":       (None, 7),
    "QED":       (0.5, None),      # 약물성 하한
    "RotB":      (None, 8),
    "Lipinski_violations": (None, 0),
}


def evaluate(smiles: str, gate: dict) -> dict:
    """단일 분자를 게이트에 통과시키고, 통과/탈락 + 사유를 반환."""
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return {
            "smiles": smiles, "status": "INVALID",
            "reasons": ["SMILES 파싱 실패 (구조적으로 불가능한 분자)"],
            "metrics": {},
        }

    # --- 물성 계산 (전부 RDKit 객관 출력값) ---
    mw   = Descriptors.MolWt(mol)
    logp = Crippen.MolLogP(mol)
    tpsa = Descriptors.TPSA(mol)
    hbd  = Lipinski.NumHDonors(mol)
    hba  = Lipinski.NumHAcceptors(mol)
    qed  = QED.qed(mol)
    rotb = Descriptors.NumRotatableBonds(mol)
    lip_v = sum([mw > 500, logp > 5, hbd > 5, hba > 10])

    metrics = {
        "MW": round(mw, 2), "LogP": round(logp, 3), "TPSA": round(tpsa, 2),
        "HBD": hbd, "HBA": hba, "QED": round(qed, 3),
        "RotB": rotb, "Lipinski_violations": lip_v,
    }

    # --- 게이트 통과 검사 + 실패 사유 수집 (이게 핵심) ---
    reasons = []
    checks = {
        "MW": mw, "LogP": logp, "TPSA": tpsa, "HBD": hbd,
        "HBA": hba, "QED": qed, "RotB": rotb, "Lipinski_violations": lip_v,
    }
    for key, bounds in gate.items():
        if key == "name":
            continue
        lo, hi = bounds
        val = checks[key]
        if lo is not None and val < lo:
            reasons.append(f"{key}={round(val,3)} < 하한 {lo} (탈락)")
        if hi is not None and val > hi:
            reasons.append(f"{key}={round(val,3)} > 상한 {hi} (탈락)")

    status = "PASS" if not reasons else "FAIL"
    return {"smiles": smiles, "status": status, "reasons": reasons, "metrics": metrics}


def screen(candidates: list, gate: dict = CNS_GATE) -> pd.DataFrame:
    """후보 리스트를 통째로 스크리닝. 성공+실패 전부 사유와 함께 보존."""
    rows = []
    for smi in candidates:
        r = evaluate(smi, gate)
        row = {"SMILES": smi, "STATUS": r["status"],
               "REASONS": " ; ".join(r["reasons"]) if r["reasons"] else "—"}
        row.update(r["metrics"])
        rows.append(row)
    df = pd.DataFrame(rows)
    return df


if __name__ == "__main__":
    # ------------------------------------------------------------------
    # 데모: AP2601(성공 기준점) + 의도적으로 다양한 실패 사례들
    # '왜 실패했는가'가 데이터로 남는지 확인
    # ------------------------------------------------------------------
    test_set = [
        # AP2601-Epsilon-OH — 통과해야 함
        "OC1(C2)CC3CC(C1)CC(C2)(C(=O)NCCC4=CC=C(OC)C=C4)C3",
        # 너무 기름진 분자 (LogP 폭발 → BBB 축적 위험)
        "CCCCCCCCCCCCCCCCCCCCc1ccccc1C(=O)NCCc1ccccc1",
        # 너무 큰 분자 (MW 초과)
        "O=C(NCCc1ccc(OC)cc1)C1(c2ccccc2)CC2CC3CC(c4ccc(Cl)cc4)(C1)CC2(c1ccccc1)C3",
        # 극성 과다 (TPSA 폭발 → BBB 못 넘음)
        "OC(=O)C(O)C(O)C(O)C(O)C(=O)NCCc1ccc(O)cc1O",
        # 단순/저약물성 (QED 낮음)
        "c1ccccc1",
        # 깨진 SMILES
        "C1CC1(",
        # 도네페질 유사 (참조 약물 — 통과 기대)
        "COc1cc2c(cc1OC)C(=O)C(CC1CCN(Cc3ccccc3)CC1)C2",
    ]

    df = screen(test_set, CNS_GATE)
    pd.set_option("display.width", 200)
    pd.set_option("display.max_colwidth", 60)
    print(f"\n게이트: {CNS_GATE['name']}")
    print("=" * 110)
    print(df[["STATUS", "MW", "LogP", "TPSA", "QED", "Lipinski_violations", "REASONS"]].to_string(index=True))
    print("=" * 110)

    n_pass = (df.STATUS == "PASS").sum()
    n_fail = (df.STATUS == "FAIL").sum()
    n_invalid = (df.STATUS == "INVALID").sum()
    print(f"\n통과(설계 가설): {n_pass}   탈락(+사유 보존): {n_fail}   무효: {n_invalid}")
    print(f"실패 데이터 비율: {(n_fail+n_invalid)/len(test_set)*100:.0f}%  ← 이게 학습 자산")

    # 실패 데이터셋만 따로 — '왜'가 붙은 negative dataset
    fails = df[df.STATUS != "PASS"][["SMILES", "STATUS", "REASONS"]]
    fails.to_csv("/home/claude/failure_dataset.csv", index=False)
    df.to_csv("/home/claude/full_screening_log.csv", index=False)
    print("\n실패 데이터셋 저장됨 → failure_dataset.csv (왜 실패했는지 사유 포함)")
